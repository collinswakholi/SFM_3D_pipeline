function o = cosg(i)

o = cos(i*pi/200);

end