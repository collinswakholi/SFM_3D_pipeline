function o = acosg(i)

o = acos(i)*200/pi;

end