function o = asing(i)

o = asin(i)*200/pi;

end